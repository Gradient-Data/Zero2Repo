"""Mutate inline-array / inline-table item lists structurally.

All structural changes to a :class:`tomlrt._values.CommaValue` pass
through this module: seam trivia ownership, bracket-pad attachment,
one-row-break-per-row, EOL
section placement, and trailing-comma policy. :mod:`tomlrt._format` is
the counterpart that canonicalises an existing layout without changing
structure.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, TypeVar

from tomlrt._list_ops import delete_runs, index_runs
from tomlrt._trivia import (
    emptied_bracket_pad,
    leading_break,
    leading_ws,
    newline_at,
    restamp_bracket_pad_for_first,
    split_eol_section,
    split_item_above,
    split_line,
    split_lines,
    strip_trailing_ws,
    trailing_ws,
)

if TYPE_CHECKING:
    from collections.abc import Iterator, Sequence
    from typing import Literal, Protocol

    from tomlrt._values import (
        CommaItem,
        CommaValue,
    )

    _EolLane = Literal["before", "after"]
    _AboveLane = Literal["before", "following"]

    class _BoundaryValue(Protocol):
        @property
        def items(self) -> Sequence[CommaItem]: ...

        opening: str


_CV_ItemT = TypeVar("_CV_ItemT", bound="CommaItem")


# ---------------------------------------------------------------------------
# Per-item EOL section helpers
# ---------------------------------------------------------------------------


def _eol_on_pre_comma(
    pre_comma: str,
    post_comma: str,
    *,
    breaks_before_comma: bool,
    has_comma: bool,
) -> bool:
    """Whether the pre-comma channel, not the post-comma one, owns the EOL.

    A comma-first row normally keeps its EOL ahead of the comma; if that
    break is structural and an EOL comment follows the comma, the
    post-comma channel owns it instead.

    Callers supply the two channels and the break decision because the
    two representations spell them differently: a live `CommaItem` holds
    flat ``before`` / ``after`` runs, while a `Boundary`
    holds the pre-comma run split into lanes and looks for the break in
    its head lane alone.
    """
    if breaks_before_comma:
        eol, _rest = split_eol_section(pre_comma)
        if eol or "#" not in post_comma:
            return True
    return not has_comma


def _seam_breaks_before_comma(item: CommaItem) -> bool:
    """Return whether the row break and any EOL comment precede the comma."""
    return item.has_comma and "\n" in item.before


def seam_eol_on_before(item: CommaItem) -> bool:
    """Whether ``before`` (rather than ``after``) owns the left item's EOL."""
    return _eol_on_pre_comma(
        item.before,
        item.after,
        breaks_before_comma=_seam_breaks_before_comma(item),
        has_comma=item.has_comma,
    )


def seam_eol_channel(item: CommaItem) -> str:
    """The trivia run that owns the item's row-attached EOL section."""
    return item.before if seam_eol_on_before(item) else item.after


def set_seam_eol_channel(item: CommaItem, text: str) -> None:
    """Write back the run that :func:`seam_eol_channel` reads."""
    if seam_eol_on_before(item):
        item.before = text
    else:
        item.after = text


def _inter_item_separator(value: CommaValue[_CV_ItemT]) -> str:
    """Structural pad before item 1; ``" "`` if there are fewer than two items.

    Excludes any above-item comment block, which belongs to the item's
    above-block rather than to the separator.
    """
    if len(value.items) >= 2:
        head, _above, tail = split_item_above(value.items[0].following)
        return head + tail
    return " "


def _take_eol(item: CommaItem) -> str:
    """Split out and return the item's row-attached EOL section.

    The item keeps only the structural rest in that channel.
    """
    if seam_eol_on_before(item):
        eol, item.before = split_eol_section(item.before)
    else:
        eol, item.after = split_eol_section(item.after)
    return eol


def _put_eol(item: CommaItem, eol: str) -> None:
    """Put a previously-taken EOL section onto the item.

    Routes to ``after`` or ``before`` according to the
    seam's *current* ``has_comma``, which may differ from the value
    at extraction time.
    """
    if not eol:
        return
    if item.has_comma:
        item.after += eol
    else:
        item.before += eol


# ---------------------------------------------------------------------------
# Above-item boundary ownership
# ---------------------------------------------------------------------------


def _first_newline_end(t: str) -> int:
    """Return the offset just after the first newline, or zero."""
    return t.find("\n") + 1


class _Lane:
    """Text partitions of one physical boundary lane."""

    __slots__ = ("above", "head", "tail")

    def __init__(self, head: str = "", above: str = "", tail: str = "") -> None:
        self.head = head
        self.above = above
        self.tail = tail

    @classmethod
    def capture(cls, trivia: str, start: int) -> _Lane:
        tail = trailing_ws(trivia[start:])
        end = len(trivia) - len(tail)
        return cls(trivia[:start], trivia[start:end], tail)

    def copy(self) -> _Lane:
        return _Lane(self.head, self.above, self.tail)

    def join(self) -> str:
        return self.head + self.above + self.tail


class Boundary:
    """Lossless snapshot of the complete region before an item or bracket."""

    __slots__ = ("after", "before", "following", "has_comma", "is_head")

    def __init__(
        self,
        before: _Lane,
        after: str,
        following: _Lane,
        has_comma: bool = False,  # noqa: FBT001, FBT002
        is_head: bool = False,  # noqa: FBT001, FBT002
    ) -> None:
        self.before = before
        self.after = after
        self.following = following
        self.has_comma = has_comma
        self.is_head = is_head

    @classmethod
    def capture(cls, cv: _BoundaryValue, i: int) -> Boundary:
        if i == 0:
            following = cv.opening
            start = _first_newline_end(following) or len(following)
            # Positional ``has_comma`` / ``is_head``: the busiest
            # boundary in an inline-array edit.
            return cls(
                _Lane(),
                "",
                _Lane.capture(following, start),
                False,  # noqa: FBT003
                True,  # noqa: FBT003
            )
        seam = cv.items[i - 1]
        following = seam.following
        before_break = seam.has_comma and "\n" in seam.before
        closed_lane = seam.after if seam.has_comma else seam.before
        row_closed = "\n" in closed_lane
        before_start = (
            _first_newline_end(seam.before) if before_break else len(seam.before)
        )
        following_start = 0 if row_closed else leading_break(following)
        return cls(
            _Lane.capture(seam.before, before_start),
            seam.after,
            _Lane.capture(following, following_start),
            seam.has_comma,
        )

    def copy(self) -> Boundary:
        return Boundary(
            self.before.copy(),
            self.after,
            self.following.copy(),
            self.has_comma,
            self.is_head,
        )

    def restore(self, cv: _BoundaryValue, i: int) -> None:
        if i == 0:
            cv.opening = self.following.join()
            return
        seam = cv.items[i - 1]
        seam.before = self.before.join()
        seam.has_comma = self.has_comma
        seam.after = self.after
        seam.following = self.following.join()

    @property
    def break_before_comma(self) -> bool:
        return self.has_comma and "\n" in self.before.head

    @property
    def row_closed(self) -> bool:
        lane = self.after if self.has_comma else self.before.head
        return "\n" in lane

    @property
    def following_break_is_structural(self) -> bool:
        return (
            not self.is_head
            and not self.row_closed
            and bool(leading_break(self.following.head))
        )

    def _eol(self) -> tuple[_EolLane | None, str]:
        """The lane owning the row-attached EOL, and its payload.

        ``None`` means no EOL is present in either pre/post-comma channel.
        """
        before = self.before.join()
        if _eol_on_pre_comma(
            before,
            self.after,
            breaks_before_comma=self.break_before_comma,
            has_comma=self.has_comma,
        ):
            lane: _EolLane = "before"
            channel = before
        else:
            lane = "after"
            channel = self.after
        eol, _rest = split_eol_section(channel)
        return (lane if eol else None), eol

    @property
    def eol(self) -> str:
        """Left-owned row-attached EOL payload."""
        return self._eol()[1]

    @property
    def eol_lane(self) -> _EolLane | None:
        """Physical pre/post-comma lane containing ``eol``."""
        return self._eol()[0]

    @property
    def above(self) -> str:
        return self.before.above + self.following.above

    def _above_lane(self, selector: _AboveLane) -> _Lane:
        return self.before if selector == "before" else self.following

    def target_lane(self) -> _AboveLane:
        if (
            self.is_head
            or not self.break_before_comma
            or self.row_closed
            or bool(self.following.head)
            or bool(self.following.above)
        ):
            return "following"
        return "before"

    @property
    def attached_lane(self) -> _AboveLane | None:
        if self.following.above:
            return "following"
        if not self.before.above:
            return None
        if self.row_closed or self.following.head:
            return None
        return "before"

    @property
    def attached_above(self) -> str | None:
        lane = self.attached_lane
        return None if lane is None else self._above_lane(lane).above

    @property
    def target_above(self) -> str:
        return self._above_lane(self.target_lane()).above

    def replace_lane(self, lane: _AboveLane, block: str, nl: str, indent: str) -> None:
        target = self._above_lane(lane)
        head = target.head
        tail = target.tail
        upstream = (
            self.break_before_comma
            if lane == "before"
            else (False if self.is_head else self.row_closed)
        )
        if block:
            # A lane whose row is still open has to break for the block;
            # whatever followed then leads a row of its own, so its old
            # intra-row pad gives way to the value indent -- and the pad
            # the break now terminates would be trailing whitespace.
            promotes = not upstream and "\n" not in head
            if promotes:
                head = strip_trailing_ws(head) + nl
            if promotes or not tail:
                tail = indent
        target.head = head
        target.above = block
        target.tail = tail

    def remove_above(self) -> Boundary:
        self.before.above = ""
        self.following.above = ""
        return self

    def remove_eol(self) -> Boundary:
        lane = self.eol_lane
        break_before_comma = self.break_before_comma
        if lane == "before":
            eol, rest = split_eol_section(self.before.head)
            self.before.head = rest
            if break_before_comma and eol.endswith("\n"):
                nl_text = "\r\n" if eol.endswith("\r\n") else "\n"
                self.before.head = nl_text + self.before.head
        elif lane == "after":
            _eol, rest = split_eol_section(self.after)
            self.after = rest
        return self

    def set_above(self, block: str, nl: str, indent: str) -> Boundary:
        before, following = self.before.above, self.following.above
        target_lane = self.target_lane()
        self.remove_above()
        if before and following:
            lines = split_lines(block)
            cut = len(split_lines(before))
            self.replace_lane("before", "".join(lines[:cut]), nl, indent)
            self.replace_lane("following", "".join(lines[cut:]), nl, indent)
        else:
            lane: _AboveLane = (
                "before" if before else "following" if following else target_lane
            )
            self.replace_lane(lane, block, nl, indent)
        return self

    def set_attached(self, block: str, nl: str, indent: str) -> Boundary:
        lane = self.attached_lane
        target = self.target_lane() if lane is None else lane
        self.replace_lane(target, block, nl, indent)
        return self

    def carry_above_from(
        self,
        source: Boundary,
        nl: str,
        indent: str,
        *,
        preserve_positional: bool = True,
    ) -> Boundary:
        row_closed = self.row_closed
        break_before_comma = self.break_before_comma
        following_head = bool(self.following.head)
        target_lane = self.target_lane()
        if not (preserve_positional and "#" not in self.above):
            self.remove_above()
        if preserve_positional and "#" not in source.above:
            return self
        before, following = source.before.above, source.following.above

        def append_to(lane: _AboveLane, block: str) -> None:
            self.replace_lane(lane, self._above_lane(lane).above + block, nl, indent)

        before_stays_attached = source.attached_lane != "before" or (
            not row_closed and not following_head
        )
        if before and break_before_comma and before_stays_attached:
            append_to("before", before)
            append_to("following", following)
        else:
            append_to(target_lane, before + following)
        return self

    def put_eol_from(self, source: Boundary, positional: Boundary) -> Boundary:
        """Put ``source``'s EOL into this positional shell."""
        source_eol = source.eol
        if not source_eol:
            return self
        lane = positional.eol_lane
        if lane is None:
            lane = (
                "after"
                if (
                    self.has_comma
                    and not (
                        source.eol_lane == "before" and positional.break_before_comma
                    )
                )
                else "before"
            )
        current = self.before.head if lane == "before" else self.after
        target = source_eol + current[leading_break(current) :]
        if lane == "before":
            self.before.head = target
        else:
            self.after = target
        return self

    def needs_carried_repair(self, old: Boundary) -> bool:
        """Unchanged row/comma state also leaves the structural break unchanged."""
        return (
            self.row_closed != old.row_closed
            or self.break_before_comma != old.break_before_comma
        )

    def shift_carried_from(
        self,
        old: Boundary,
        nl: str,
        indent: str,
        *,
        is_terminal: bool,
    ) -> None:
        """Repair this boundary's structural break after its left item moves."""
        if not self.needs_carried_repair(old):
            return
        row_closed = self.row_closed
        break_before_comma = self.break_before_comma
        current_structural = (
            False if row_closed else old.row_closed or old.following_break_is_structural
        )
        delta = int(current_structural) - int(old.following_break_is_structural)
        holder = self.following.join()
        if delta:
            holder = shift_breaks(holder, delta, nl)
        if (
            not is_terminal
            and (row_closed or break_before_comma)
            and not leading_break(holder)
        ):
            holder = (
                reindent_as_leader(holder, indent)
                if row_closed
                else holder.lstrip(" \t")
            )
        following_start = 0 if row_closed else leading_break(holder)
        self.following = _Lane.capture(holder, following_start)


# ---------------------------------------------------------------------------
# Row-break maintenance
# ---------------------------------------------------------------------------
#
# Each multi-line boundary has one structural row break; any further break
# is authored whitespace. Fresh boundaries can drop a redundant separator
# directly, while carried boundaries shift only that structural break.


def _structural_break(seam: CommaItem, nl: str) -> None:
    """Drop a fresh separator when the seam's EOL already closes its row."""
    seam.following = shift_breaks(
        seam.following, -int("\n" in seam_eol_channel(seam)), nl
    )


def shift_breaks(t: str, delta: int, nl: str) -> str:
    """Shift leading structural newlines without disturbing later trivia."""
    if delta > 0:
        return nl * delta + t
    for _ in range(-delta):
        k = leading_break(t)
        assert k
        t = t[k:]
    return t


def _shift_carried_boundary(
    cv: CommaValue[_CV_ItemT],
    b: int,
    nl: str,
    *,
    old: Boundary,
) -> None:
    """Repair a carried boundary after its predecessor changes."""
    current = Boundary.capture(cv, b)
    if not current.needs_carried_repair(old):
        return
    current.shift_carried_from(
        old,
        nl,
        _value_indent(cv),
        is_terminal=b >= len(cv.items),
    )
    current.restore(cv, b)


def reindent_as_leader(holder: str, indent: str) -> str:
    """Promote a shared-row follower to a row leader at ``indent``."""
    return indent + holder.lstrip(" \t")


# ---------------------------------------------------------------------------
# Comma / terminal-state flips
# ---------------------------------------------------------------------------


def flip_to_internal(item: CommaItem) -> None:
    """Add an internal comma while keeping the item's EOL attached."""
    if item.has_comma:
        return
    eol = _take_eol(item)
    item.has_comma = True
    _put_eol(item, eol)


# ---------------------------------------------------------------------------
# Style detection
# ---------------------------------------------------------------------------


class CommaStyle:
    """Hold inferred layout policy for inline array/table append paths.

    A non-empty ``pre_comma_break`` marks a *break-before-comma*
    (comma-first) value: one that parks each row break in the item's
    outgoing seam's ``before`` rather than downstream in its
    ``following``, so ``inter_separator`` is just the
    post-comma pad.
    """

    __slots__ = (
        "inter_separator",
        "is_multiline",
        "pre_comma_break",
        "trailing_comma",
    )

    def __init__(
        self,
        is_multiline: bool,  # noqa: FBT001
        inter_separator: str,
        trailing_comma: bool,  # noqa: FBT001
        pre_comma_break: str,
    ) -> None:
        self.is_multiline = is_multiline
        self.inter_separator = inter_separator
        self.trailing_comma = trailing_comma
        self.pre_comma_break = pre_comma_break

    @property
    def break_before_comma(self) -> bool:
        return bool(self.pre_comma_break)


def _pre_comma_break(item: CommaItem) -> str:
    """The row break a break-before-comma ``item`` parks before its comma.

    Sampled so a new internal item matches the authored newline and the
    comma-row indent (the trailing whitespace between break and comma).
    """
    t = item.before
    i = t.find("\n")
    return newline_at(t, i) + trailing_ws(t)


def detect_style(value: CommaValue[_CV_ItemT]) -> CommaStyle:
    """Infer a :class:`CommaStyle` for ``value``.

    Multi-line shape comes from the value's own trivia
    (:meth:`CommaValue.is_multiline`) -- there is no separate "force
    multi-line" flag. The inter-item separator is sampled from
    ``items[0].following``, falling back to :func:`_canonical_separator`
    for a comma-last multi-line value with only one item to sample
    from. When item 0 parks its break before its comma the value is
    comma-first: the post-comma pad is kept and ``pre_comma_break``
    seeded from that item.
    """
    items = value.items
    is_multiline = value.is_multiline()
    inter_sep = _inter_item_separator(value)
    leader = items[0] if items and _seam_breaks_before_comma(items[0]) else None
    if is_multiline and leader is None and "\n" not in inter_sep:
        inter_sep = _canonical_separator(value)
    trailing_comma = items[-1].has_comma if items else is_multiline
    return CommaStyle(
        is_multiline,
        inter_sep,
        trailing_comma,
        _pre_comma_break(leader) if leader else "",
    )


def _row_runs(value: CommaValue[_CV_ItemT]) -> Iterator[str]:
    """Yield ``value``'s interior trivia as physically contiguous runs.

    Rendering each seam keeps a row break and the indent it opens in
    one string however its channels split them.
    """
    yield value.opening
    for item in value.items:
        yield item.render_tail()


def _value_newline(value: CommaValue[_CV_ItemT]) -> str:
    """Return the newline text ``value`` already breaks its rows with.

    The first break wins, wherever it lives -- an item's EOL section
    included. Only a multi-line value has a break to sample, and always
    has one: the runs cover every rendered channel of the value's seams.
    """
    run = next(run for run in _row_runs(value) if "\n" in run)
    i = run.index("\n")
    return newline_at(run, i)


def _value_indent(value: CommaValue[_CV_ItemT]) -> str:
    """Return the row indent sampled from ``value`` (4 spaces if none).

    The first indented row the value opens wins, wherever its break
    lives -- so a value that already breaks rows lends its own indent
    even when its opening row packs several items, and a row at column
    zero yields to a later indented one, as when a comment sits hard
    against the bracket. Only a value whose rows are all flush left
    means column zero.
    """
    opens_row = False
    for run in _row_runs(value):
        rows = run.split("\n")[1:]
        opens_row = opens_row or bool(rows)
        for row in rows:
            if ws := leading_ws(row):
                return ws
    return "" if opens_row else "    "


def _canonical_separator(value: CommaValue[_CV_ItemT]) -> str:
    """Return the fallback inter-item newline plus value indent."""
    return _value_newline(value) + _value_indent(value)


def _carry_above(
    cv: CommaValue[_CV_ItemT],
    i: int,
    source: Boundary,
    nl: str,
    indent: str,
    *,
    preserve_positional: bool = True,
) -> None:
    Boundary.capture(cv, i).carry_above_from(
        source,
        nl,
        indent,
        preserve_positional=preserve_positional,
    ).restore(cv, i)


def _replace_above(
    cv: CommaValue[_CV_ItemT], i: int, source: Boundary, nl: str, indent: str = ""
) -> None:
    _carry_above(
        cv,
        i,
        source,
        nl,
        indent,
        preserve_positional=False,
    )


def _detach_above(cv: CommaValue[_CV_ItemT], b: int) -> Boundary:
    """Snapshot boundary ``b``, stripping any comment block it owns.

    An above-block belongs to the item below it, so an insertion here
    has to lift the block out of the way and re-home it (with
    :func:`_rehome_above`) once the items have moved. :class:`Boundary`
    finds the block wherever the row break ahead of it lives, so every
    spelling of a layout is treated alike. The returned snapshot retains
    the block.
    """
    boundary = Boundary.capture(cv, b)
    if "#" in boundary.above:
        boundary.copy().remove_above().restore(cv, b)
    return boundary


def _rehome_above(
    cv: CommaValue[_CV_ItemT], i: int, source: Boundary, style: CommaStyle, nl: str
) -> None:
    """Put the block ``source`` was detached from above the item at ``i``.

    A comma-first item sits on its comma's row, so that row's authored
    indent -- possibly none -- is the one the block aligns with.
    """
    if "#" not in source.above:
        return
    indent = (
        trailing_ws(style.pre_comma_break)
        if style.break_before_comma
        else _value_indent(cv)
    )
    _carry_above(cv, i, source, nl, indent)


# ---------------------------------------------------------------------------
# Append / remove / reorder orchestration
# ---------------------------------------------------------------------------


def splice_in(
    cv: CommaValue[_CV_ItemT],
    new_item: _CV_ItemT,
    style: CommaStyle,
    nl: str,
) -> None:
    """Append ``new_item`` while preserving the inferred comma style."""
    items = cv.items
    if not items:
        header, final = restamp_bracket_pad_for_first(cv.opening)
        if cv._single_line_pad and not header and not final:  # noqa: SLF001
            header = final = cv._single_line_pad  # noqa: SLF001
        cv.opening = header
        new_item.has_comma = style.trailing_comma
        new_item.following = final
        items.append(new_item)
        return
    old_tail = items[-1]
    old_final = _detach_above(cv, len(items))
    new_item.has_comma = style.trailing_comma
    new_item.following = old_tail.following
    old_tail.following = style.inter_separator
    if style.break_before_comma:
        # Comma-first: the former tail keeps its EOL comment but yields its
        # terminal break (re-homed before the closing bracket) and gains its
        # own pre-comma break; the new tail needs no trailing break.
        eol = _take_eol(old_tail).rstrip("\r\n")
        old_tail.before = eol + style.pre_comma_break
        old_tail.has_comma = True
        if "\n" not in new_item.following:
            new_item.following = nl + new_item.following
    else:
        flip_to_internal(old_tail)
    items.append(new_item)
    if style.is_multiline and not style.break_before_comma:
        # Fresh boundary onto the new item; carried final boundary, whose
        # predecessor changes from the old tail to the new item.
        _structural_break(old_tail, nl)
        _shift_carried_boundary(
            cv,
            len(items),
            nl,
            old=old_final,
        )
    # A block that sat above the closing bracket belongs above the
    # appended item, at the seam the append created.
    _rehome_above(cv, len(items) - 1, old_final, style, nl)


def splice_insert(
    cv: CommaValue[_CV_ItemT],
    new_items: Sequence[_CV_ItemT],
    index: int,
    nl: str,
) -> None:
    """Insert a non-empty run, sampling style again after its first item."""
    items = cv.items
    # The first insertion can change the sampled separator; the rest share it.
    runs = (new_items[:1], new_items[1:]) if len(new_items) > 1 else (new_items,)
    for run in runs:
        style = detect_style(cv)
        displaced = _detach_above(cv, index)
        count = len(run)
        for item in run:
            item.before = style.pre_comma_break
            item.has_comma = True
            item.following = style.inter_separator
        if index:
            pred = items[index - 1]
            run[-1].following = pred.following
            pred.following = style.inter_separator
        items[index:index] = run
        if style.is_multiline and not style.break_before_comma:
            if index == 0:
                _structural_break(run[-1], nl)
            else:
                _structural_break(items[index - 1], nl)
                _shift_carried_boundary(cv, index + count, nl, old=displaced)
        index += count
        _rehome_above(cv, index, displaced, style, nl)


def splice_out(
    cv: CommaValue[_CV_ItemT],
    removed_indices: Sequence[int],
    nl: str,
    *,
    is_multiline: bool,
) -> None:
    """Remove valid distinct item indices and repair the surviving seams."""
    assert removed_indices
    items = cv.items
    assert items
    # A single-line value cannot gain a newline by removal, so only a
    # currently multi-line value can flip (the removed item may hold the
    # sole newline, or emptying may collapse the pads).
    if is_multiline:
        cv.reset_multiline_cache()
    orig_len = len(items)
    removed_runs = index_runs(sorted(removed_indices))
    last_idx = orig_len - 1

    # Removal only disturbs the boundaries adjacent to a run of removed
    # items, so walk the runs: the cost is in what is removed, not in how
    # many items the value holds. A run bounded by survivors on both sides
    # leaves a seam, recorded as (position after removal, boundary before);
    # a run reaching an end of the value exposes the survivor beyond it.
    seams: list[tuple[int, int]] = []
    first_survivor: int | None = None
    last_survivor: int | None = None
    dropped = 0
    for start, stop in removed_runs:
        if start == 0:
            first_survivor = stop if stop < orig_len else None
        elif stop == orig_len:
            last_survivor = start - 1
        else:
            seams.append((start - dropped, stop))
        dropped += stop - start

    needed = {boundary for _, boundary in seams}
    if first_survivor is not None:
        needed.add(first_survivor)
    if last_survivor is not None:
        needed.update((last_survivor + 1, orig_len))
    boundaries_before = {b: Boundary.capture(cv, b) for b in needed}
    new_last_eol = ""
    new_terminal_has_comma = False
    if last_survivor is not None:
        left_boundary = last_survivor + 1
        boundaries_before[left_boundary].copy().remove_above().restore(
            cv, left_boundary
        )
        new_last_eol = _take_eol(items[last_survivor])
        new_terminal_has_comma = items[last_idx].has_comma

    final = items[-1].following
    for start, stop in removed_runs:
        if start:
            items[start - 1].following = items[stop - 1].following
    delete_runs(items, removed_runs)

    if not items:
        cv.opening = emptied_bracket_pad(cv.opening, final)
        return
    if last_survivor is not None:
        new_last = items[-1]
        new_last.after = ""
        new_last.has_comma = new_terminal_has_comma
        if not new_terminal_has_comma and "\n" in new_last.before:
            new_last.before = ""
        _put_eol(new_last, new_last_eol)
        if is_multiline:
            _shift_carried_boundary(
                cv,
                len(items),
                nl,
                old=boundaries_before[orig_len],
            )
    if is_multiline:
        for pos, boundary in seams:
            _shift_carried_boundary(cv, pos, nl, old=boundaries_before[boundary])
    indent = (
        _value_indent(cv)
        if any(boundary.above for boundary in boundaries_before.values())
        else ""
    )
    if first_survivor is not None:
        _replace_above(cv, 0, boundaries_before[first_survivor], nl, indent)
    for pos, boundary in seams:
        _replace_above(cv, pos, boundaries_before[boundary], nl, indent)
    if last_survivor is not None:
        _replace_above(cv, len(items), boundaries_before[orig_len], nl)


def reorder_owned(
    cv: CommaValue[_CV_ItemT],
    owned_positions: Sequence[int],
    new_owned: Sequence[_CV_ItemT],
    nl: str,
    *,
    is_multiline: bool,
) -> None:
    """Reorder selected items while boundary shells stay positional."""
    if len(owned_positions) <= 1:
        return
    assert len(owned_positions) == len(new_owned)
    items = cv.items
    if all(
        items[pos] is entry
        for pos, entry in zip(owned_positions, new_owned, strict=True)
    ):
        return
    affected = {b for pos in owned_positions for b in (pos, pos + 1)}
    boundaries = {b: Boundary.capture(cv, b) for b in affected}
    above_by_item = {items[pos]: boundaries[pos] for pos in owned_positions}
    left_by_item = {items[pos]: boundaries[pos + 1] for pos in owned_positions}
    owned = set(owned_positions)
    incoming = dict(zip(owned_positions, new_owned, strict=True))
    indent = _value_indent(cv)
    composed: dict[int, Boundary] = {}
    for b, boundary in boundaries.items():
        shell = boundary.copy()
        if b in owned and "#" in shell.above:
            shell.remove_above()
        if b - 1 in owned:
            shell.remove_eol()
        left = incoming.get(b - 1)
        if left is not None:
            shell.put_eol_from(left_by_item[left], boundary)
        if is_multiline and b - 1 in owned:
            shell.shift_carried_from(
                boundary,
                nl,
                indent,
                is_terminal=b == len(items),
            )
        right = incoming.get(b)
        if right is not None:
            shell.carry_above_from(above_by_item[right], nl, indent)
        composed[b] = shell

    for pos, entry in incoming.items():
        items[pos] = entry
    for b in sorted(affected):
        composed[b].restore(cv, b)


def strip_framing_comments(cv: CommaValue[_CV_ItemT]) -> None:
    """Remove bracket-owned comments from a nonempty extracted value."""
    opening = Boundary.capture(cv, 0)
    _pad, comment, terminator = split_line(opening.following.head)
    if comment:
        opening.following.head = terminator
    opening.restore(cv, 0)
    Boundary.capture(cv, len(cv.items)).remove_above().restore(cv, len(cv.items))


__all__ = [
    "Boundary",
    "CommaStyle",
    "detect_style",
    "reindent_as_leader",
    "reorder_owned",
    "seam_eol_channel",
    "seam_eol_on_before",
    "set_seam_eol_channel",
    "shift_breaks",
    "splice_in",
    "splice_insert",
    "splice_out",
    "strip_framing_comments",
]
