"""Array views: `Array` for inline arrays, `AoT` for arrays-of-tables."""

from __future__ import annotations

import operator
import sys
from typing import TYPE_CHECKING, Any, SupportsIndex, TypeVar, overload

if sys.version_info >= (3, 12):
    from typing import override
else:  # pragma: no cover -- backport for Python < 3.12
    from typing_extensions import override

from copy import deepcopy

from tomlrt import _container, _layout_ops
from tomlrt._array_comments import _ArrayAdapter
from tomlrt._comma_comments import (
    CommaEolView,
    CommaLeadingBlockView,
    CommaLeadingView,
)
from tomlrt._comma_ops import (
    detect_style,
    reorder_owned,
    splice_in,
    splice_insert,
    splice_out,
)
from tomlrt._format import (
    _prepare_indent,
    _resolve_format_options,
    format_inline_root,
    set_comma_value_multiline,
)
from tomlrt._trivia import (
    emptied_bracket_pad,
)
from tomlrt._typecheck import _require_mapping, _validate_mapping
from tomlrt._values import (
    ArrayItem,
    ArrayValue,
)
from tomlrt._view import _View

if TYPE_CHECKING:
    from collections.abc import (
        Callable,
        Iterable,
        Iterator,
        Mapping,
        MutableMapping,
        Sequence,
    )
    from typing import Self

    from _typeshed import SupportsRichComparison

    from tomlrt._comma_ops import (
        CommaStyle,
    )
    from tomlrt._container import Container, Document, Table, TomlInput
    from tomlrt._format import FormatOptions
    from tomlrt._values import (
        Value,
    )


_T = TypeVar("_T")


class Array(_View, list[Any]):
    """An inline TOML array.

    `Array` is a `list` subclass, so ``isinstance(arr, list)`` holds and
    it can be passed wherever a `list` or `Sequence` is expected.
    """

    __slots__ = ("_host", "_layout_root", "_name", "_value")

    _inline = True

    @classmethod
    def _view(
        cls,
        value: ArrayValue,
        layout_root: Document | None,
        name: str | None = None,
        host: Array | Container | None = None,
    ) -> Array:
        """View over existing CST, holding no items yet.

        The public constructor goes the other way: it synthesises CST from
        Python items. This is for callers that already have CST and fill
        the items in themselves. ``name`` is the key the array is bound
        under and ``host`` is where it is bound -- its containing array
        when it is an element, else its hosting container. A caller that
        does not yet know where the array lands leaves ``host`` unset for
        the value funnel to stamp later (see `_file_host`).
        """
        arr = cls.__new__(cls)
        arr._value = value  # noqa: SLF001
        arr._layout_root = layout_root  # noqa: SLF001
        arr._host = host  # noqa: SLF001
        arr._name = name or ""  # noqa: SLF001
        return arr

    def __init__(
        self,
        items: Iterable[TomlInput] = (),
        *,
        multiline: bool = False,
        indent: int = 4,
    ) -> None:
        """Construct a standalone inline array.

        ``Array([1, 2, 3])`` builds an inline array; ``multiline=True``
        lays items out one per line, indented by ``indent`` spaces.
        """
        super().__init__()

        val = ArrayValue()
        self._value: ArrayValue = val
        self._layout_root: Document | None = None
        self._host: Array | Container | None = None
        self._name: str = ""
        items_list = list(items)
        for item in items_list:
            self._validate_item(item)
        indent_text = _prepare_indent(indent) if multiline else ""
        if items_list:
            from tomlrt._container import _fill_inline_array  # noqa: PLC0415

            _fill_inline_array(self, items_list, layout_root=None, owner=None)
        if not multiline:
            return
        set_comma_value_multiline(
            val,
            multiline=True,
            nl=self._doc_newline,
            indent=indent_text,
            host=None,
        )

    def to_list(self) -> list[Any]:
        """Return a deep copy as a plain Python list."""
        from tomlrt._container import _to_python  # noqa: PLC0415

        out = _to_python(self)
        assert isinstance(out, list)
        return out

    @override
    def __copy__(self) -> Array:
        _container._validate_input(self, inline_only=True)  # noqa: SLF001
        cloned = _container._copy_input(self)  # noqa: SLF001
        assert isinstance(cloned, Array)
        return cloned

    def array(self, index: SupportsIndex) -> Array:
        """Return ``self[index]`` typed as a nested `Array`."""
        return self._typed_item(index, Array, "an Array")

    def table(self, index: SupportsIndex) -> Table:
        """Return ``self[index]`` typed as a `Table`."""
        return self._typed_item(index, _container.Table, "a Table")

    @overload
    def get_array(self, index: SupportsIndex) -> Array | None: ...
    @overload
    def get_array(self, index: SupportsIndex, default: _T) -> Array | _T: ...
    def get_array(self, index: SupportsIndex, default: object = None) -> object:
        """Like `array(index)` but returns ``default`` for out-of-range."""
        try:
            return self.array(index)
        except IndexError:
            return default

    @overload
    def get_table(self, index: SupportsIndex) -> Table | None: ...
    @overload
    def get_table(self, index: SupportsIndex, default: _T) -> Table | _T: ...
    def get_table(self, index: SupportsIndex, default: object = None) -> object:
        """Like `table(index)` but returns ``default`` for out-of-range."""
        try:
            return self.table(index)
        except IndexError:
            return default

    def _typed_item(self, index: SupportsIndex, cls: type[_T], label: str) -> _T:
        v = self[index]
        if not isinstance(v, cls):
            msg = f"item at {index} is {type(v).__name__}, not {label}"
            raise TypeError(msg)
        return v

    @override
    def _view_children(self) -> Iterator[object]:
        return list.__iter__(self)

    @override
    def _reset_displaced(self) -> None:
        # ``_value`` stays: it's reused if this view is attached elsewhere.
        self._layout_root = None

    def _style(self) -> CommaStyle:
        return detect_style(self._value)

    @property
    def multiline(self) -> bool:
        """Whether this array is written across multiple lines."""
        return self._value.is_multiline()

    @multiline.setter
    def multiline(self, value: bool) -> None:
        if self.multiline == value:
            return
        self.set_multiline(multiline=value)

    @property
    def comments(self) -> MutableMapping[int, str]:
        """End-of-line comments, keyed by item index."""
        return CommaEolView(_ArrayAdapter(self))

    @property
    def leading_comments(self) -> MutableMapping[int, tuple[str, ...]]:
        """Comment lines immediately above each item, keyed by item index."""
        return CommaLeadingView(_ArrayAdapter(self))

    @property
    def leading_block(self) -> MutableMapping[int, tuple[str | None, ...]]:
        """Comments and blank lines above each item, keyed by item index.

        Comment lines are strings and blank lines are ``None``.
        """
        return CommaLeadingBlockView(_ArrayAdapter(self))

    def format(
        self,
        *,
        options: FormatOptions | None = None,
    ) -> None:
        """Canonicalise this array's formatting in place.

        Rewrites whitespace, indentation, separators, and newlines
        while retaining comments and keeping multi-line values multi-line.
        A multi-line array's closing bracket lines up with the row the
        array starts on.

        Use ``FormatOptions(normalize_comments=False)`` to leave comment
        text untouched.
        """
        resolved = _resolve_format_options(options=options)
        from tomlrt._container import _host_kv_slot  # noqa: PLC0415

        format_inline_root(
            self._value,
            nl=self._doc_newline,
            options=resolved,
            host=_host_kv_slot(self),
        )

    def set_multiline(self, *, multiline: bool, indent: int = 4) -> Array:
        """Switch this array between single-line and multi-line form.

        When laying out multi-line, items are indented by ``indent``
        spaces and the closing bracket lines up with the row the array
        starts on.

        Raises ``TOMLError`` when collapsing a multi-line array that
        carries comments anywhere in it, including inside nested values,
        since they would have nowhere to live on one line.

        Returns ``self`` for chaining.
        """
        from tomlrt._container import _host_kv_slot  # noqa: PLC0415

        set_comma_value_multiline(
            self._value,
            multiline=multiline,
            nl=self._doc_newline,
            indent=_prepare_indent(indent) if multiline else "",
            host=_host_kv_slot(self),
        )
        return self

    @staticmethod
    def _validate_item(value: object) -> None:
        """Validate one value before synthesis can attach nested views."""
        from tomlrt._container import _validate_input  # noqa: PLC0415

        _validate_input(value, inline_only=True, inline_kind="array")

    def _synth_item(self, value: TomlInput) -> tuple[Value, object]:
        """Synthesise one validated value for this inline array."""
        from tomlrt._container import _synth_value  # noqa: PLC0415

        return _synth_value(
            value,
            layout_root=self._layout_root,
            parent=None,
            name=None,
            owner=None,
            array_host=self,
        )

    def _prepare_item(self, value: TomlInput) -> tuple[Value, object]:
        """Validate and synthesise one value."""
        self._validate_item(value)
        return self._synth_item(value)

    def _prepare_values(
        self, values: Sequence[TomlInput]
    ) -> list[tuple[Value, object]]:
        """Validate a batch before synthesis can attach any nested views."""
        self._validate_values(values)
        return [self._synth_item(value) for value in values]

    def _validate_values(self, values: Sequence[TomlInput]) -> None:
        """Validate a batch before any item is synthesised."""
        for value in values:
            self._validate_item(value)

    @override
    def append(self, value: Any) -> None:
        cst, decoded = self._prepare_item(value)
        self._append_with_style(cst, decoded, self._style())

    def _append_with_style(
        self, cst: Value, decoded: object, style: CommaStyle
    ) -> None:
        """Append an already-synthesised item with the sampled layout."""
        new_item = ArrayItem(cst)
        splice_in(self._value, new_item, style, self._doc_newline)
        list.append(self, decoded)

    def _extend_prepared(self, prepared: Iterable[tuple[Value, object]]) -> None:
        """Append a batch; the first two items establish bracket pad and separator."""
        style = self._style()
        for cst, decoded in prepared:
            self._append_with_style(cst, decoded, style)
            if len(self) <= 2:
                style = self._style()

    @override
    def extend(self, values: Iterable[Any]) -> None:
        # Snapshot so ``arr.extend(arr)`` duplicates once like list does.
        snapshot = list(values)
        if not snapshot:
            return
        prepared = self._prepare_values(snapshot)
        self._extend_prepared(prepared)

    @override
    def clear(self) -> None:
        if not self:
            return
        _layout_ops.reset_displaced_views(*self)
        self._value.opening = emptied_bracket_pad(
            self._value.opening, self._value.items[-1].following
        )
        self._value.items.clear()
        list.clear(self)
        self._value.reset_multiline_cache()

    @override
    def pop(self, index: SupportsIndex = -1) -> Any:
        i = _norm_index(index, len(self), "pop")
        decoded = self[i]
        del self[i]
        return decoded

    @override
    def remove(self, value: Any) -> None:
        _remove_value(self, value, "Array.remove(x): x not in array")

    @override
    def insert(self, index: SupportsIndex, value: Any) -> None:
        i = _norm_insert_index(index, len(self))
        cst, decoded = self._prepare_item(value)
        if i == len(self):
            self._append_with_style(cst, decoded, self._style())
            return
        new_item = ArrayItem(cst)
        splice_insert(self._value, (new_item,), i, self._doc_newline)
        list.insert(self, i, decoded)

    def _replace_synthesised(self, index: int, cst: Value, decoded: object) -> None:
        """Replace an item with an already-synthesised value."""
        old = self[index]
        # Exact same-position assignments returned before synthesis.
        _layout_ops.reset_displaced_views(old)
        self._value.items[index].value = cst
        list.__setitem__(self, index, decoded)

    @override
    def reverse(self) -> None:
        self._reorder(list(reversed(range(len(self)))))

    @override
    def sort(
        self,
        *,
        key: Callable[[Any], SupportsRichComparison] | None = None,
        reverse: bool = False,
    ) -> None:
        n = len(self)
        order = sorted(
            range(n),
            key=lambda i: self[i] if key is None else key(self[i]),
            reverse=reverse,
        )
        self._reorder(order)

    def _reorder(self, order: list[int]) -> None:
        """Apply index permutation to items, decoded list, and per-item comments."""
        items = self._value.items
        if not items:
            return
        new_items = [items[j] for j in order]
        new_decoded = [self[j] for j in order]
        reorder_owned(
            self._value,
            range(len(items)),
            new_items,
            self._doc_newline,
            is_multiline=self._style().is_multiline,
        )
        list.__init__(self, new_decoded)

    @overload
    def __setitem__(self, index: SupportsIndex, value: Any) -> None: ...
    @overload
    def __setitem__(self, index: slice, value: Iterable[Any]) -> None: ...
    @override
    def __setitem__(
        self,
        index: SupportsIndex | slice,
        value: Any,
    ) -> None:
        if isinstance(index, slice):
            try:
                values = list(value)
            except TypeError as exc:
                msg = "can only assign an iterable"
                raise TypeError(msg) from exc
            start, stop, step = index.indices(len(self))
            indices = range(start, stop, step)
            if step != 1 and len(values) != len(indices):
                msg = (
                    f"attempt to assign sequence of size {len(values)} "
                    f"to extended slice of size {len(indices)}"
                )
                raise ValueError(msg)
            self._validate_values(values)
            if len(values) == len(indices) and all(
                self[i] is v for i, v in zip(indices, values, strict=True)
            ):
                return
            prepared = [self._synth_item(v) for v in values]
            if step != 1:
                # Extended slice positions are unchanged; replace per slot.
                for k, (cst, decoded) in zip(indices, prepared, strict=True):
                    self._replace_synthesised(k, cst, decoded)
                return
            # Reuse delete/insert boundary handling for contiguous slices.
            del self[start:stop]
            if prepared:
                if start == len(self):
                    self._extend_prepared(prepared)
                else:
                    new_items = [ArrayItem(cst) for cst, _ in prepared]
                    splice_insert(self._value, new_items, start, self._doc_newline)
                    list.__setitem__(
                        self, slice(start, start), [decoded for _, decoded in prepared]
                    )
            return
        # int index: reject before synthesising or mutating any CST, to
        # match the IndexError ``list.__setitem__`` raises for a bad index.
        i = _norm_index(index, len(self._value.items), "list assignment")
        self._validate_item(value)
        if self[i] is value:
            return
        cst, dec = self._synth_item(value)
        self._replace_synthesised(i, cst, dec)

    @override
    def __delitem__(self, index: SupportsIndex | slice) -> None:
        items = self._value.items
        if isinstance(index, slice):
            removed = list(range(*index.indices(len(items))))
            if not removed:
                return
        else:
            removed = [_norm_index(index, len(items), "list assignment")]
        _layout_ops.reset_displaced_views(*(self[i] for i in removed))
        list.__delitem__(self, index if isinstance(index, slice) else removed[0])
        splice_out(
            self._value,
            removed,
            self._doc_newline,
            is_multiline=self._value.is_multiline(),
        )

    @override
    def __iadd__(self, values: Iterable[Any]) -> Self:
        self.extend(values)
        return self

    @override
    def __imul__(self, count: SupportsIndex) -> Self:
        n = operator.index(count)
        if n <= 0:
            self.clear()
            return self
        if n == 1:
            return self
        # Snapshot the source list before appending grows it; each copy needs
        # its own decoded views.
        from tomlrt._build import _decode_value  # noqa: PLC0415

        src_items = list(self._value.items)

        def copies() -> Iterator[tuple[Value, object]]:
            for _ in range(n - 1):
                for src in src_items:
                    cst = deepcopy(src.value)
                    yield (
                        cst,
                        _decode_value(cst, self._layout_root, None, None, None, self),
                    )

        self._extend_prepared(copies())
        return self


def _remove_value(items: list[_T], value: object, message: str) -> None:
    """Remove the first identity-or-equality match through the live list API."""
    for i, item in enumerate(items):
        if item is value or item == value:
            del items[i]
            return
    raise ValueError(message)


def _norm_insert_index(index: SupportsIndex, n: int) -> int:
    """Return the clamped index used by ``list.insert``."""
    i = operator.index(index)
    return max(0, n + i) if i < 0 else min(i, n)


def _norm_index(index: SupportsIndex, n: int, action: str) -> int:
    """Return non-negative in-range index, or raise IndexError.

    ``action`` is used verbatim in the error message
    (e.g. ``"pop"`` → ``"pop index out of range"``).
    """
    i = operator.index(index)
    if i < 0:
        i += n
    if i < 0 or i >= n:
        msg = f"{action} index out of range"
        raise IndexError(msg)
    return i


class AoT(_View, list["Table"]):
    """An array of tables, written as repeated headers such as ``[[products]]``.

    `AoT` is a `list[Table]` subclass, so ``isinstance(aot, list)`` holds
    and it can be passed wherever a `list` or `Sequence` is expected.
    """

    __slots__ = ("_host", "_layout_root", "_path")

    _inline = False

    @override
    def _view_children(self) -> Iterator[object]:
        return list.__iter__(self)

    def __init__(self, entries: Iterable[Mapping[str, TomlInput]] = ()) -> None:
        """Construct a standalone array-of-tables."""
        super().__init__()
        self._layout_root: Document | None = None
        self._path: tuple[str, ...] = ()
        self._host: Container | None = None
        for entry in entries:
            e = _validate_mapping(entry, label="AoT entry")
            list.append(self, _make_unattached_entry(e))

    def _unbind_from_document(self) -> None:
        """Detach from the owning document.

        Called once this AoT has left its document, so a caller still
        holding the view can no longer write through it.
        """
        self._layout_root = None
        self._host = None
        self._path = ()

    def to_list(self) -> list[dict[str, Any]]:
        """Return a deep copy as a list of plain Python dictionaries."""
        out = _container._to_python(self)  # noqa: SLF001
        assert isinstance(out, list)
        return out

    @override
    def __copy__(self) -> AoT:
        _container._validate_input(self, inline_only=False)  # noqa: SLF001
        cloned = _container._copy_input(self)  # noqa: SLF001
        assert isinstance(cloned, AoT)
        return cloned

    def add(self, entry: Mapping[str, TomlInput] | None = None) -> Table:
        """Append a table and return it.

        ``entry`` supplies the table's initial values; ``None`` creates an
        empty table.
        """
        body = _prepare_aot_entries((entry,))[0] if entry is not None else None
        if self._layout_root is None:
            list.append(self, _make_unattached_entry(body))
            return self[-1]
        return _layout_ops.add_aot_entry(self, body)

    # Each of these must route attached vs. detached AoTs differently:
    # inherited `list` behaviour alone would corrupt the doc-stream.

    @override
    def pop(self, index: SupportsIndex = -1) -> Table:
        i = _norm_index(index, len(self), "pop")
        if self._layout_root is None:
            return list.pop(self, i)
        return _layout_ops.remove_aot_entry(self, i)

    @override
    def __delitem__(self, index: SupportsIndex | slice) -> None:
        if isinstance(index, slice):
            if self._layout_root is None:
                list.__delitem__(self, index)
                return
            indices = sorted(set(range(*index.indices(len(self)))))
            if indices:
                _layout_ops.remove_aot_entries(self, indices)
            return
        if self._layout_root is None:
            list.__delitem__(self, index)
            return
        _layout_ops.remove_aot_entry(self, operator.index(index))

    @override
    def clear(self) -> None:
        if self._layout_root is None:
            list.clear(self)
            return
        n = len(self)
        if n:
            _layout_ops.remove_aot_entries(self, range(n))

    @overload
    def __setitem__(
        self, index: SupportsIndex, value: Mapping[str, TomlInput]
    ) -> None: ...
    @overload
    def __setitem__(
        self, index: slice, value: Iterable[Mapping[str, TomlInput]]
    ) -> None: ...
    @override
    def __setitem__(
        self,
        index: SupportsIndex | slice,
        value: Any,
    ) -> None:
        if isinstance(index, slice):
            try:
                values = list(value)
            except TypeError as exc:
                msg = "can only assign an iterable"
                raise TypeError(msg) from exc
            indices = list(range(*index.indices(len(self))))
            if (
                index.step is not None
                and index.step != 1
                and len(values) != len(indices)
            ):
                msg = (
                    f"attempt to assign sequence of size {len(values)} "
                    f"to extended slice of size {len(indices)}"
                )
                raise ValueError(msg)
            # Atomicity preflight: validate everything before mutating.
            typed_values = _prepare_aot_entries(values)
            if self._layout_root is None:
                list.__setitem__(
                    self, index, [_make_unattached_entry(v) for v in typed_values]
                )
                return
            _layout_ops.assign_aot_entries(self, index, typed_values)
            return
        entry = _prepare_aot_entries((value,))[0]
        if self._layout_root is None:
            list.__setitem__(self, index, _make_unattached_entry(entry))
            return
        _layout_ops.assign_aot_entries(self, operator.index(index), (entry,))

    @override
    def append(self, value: Table | Mapping[str, TomlInput]) -> None:
        # Same semantics as `add(body)` but with no return value (list API).
        entry = _prepare_aot_entries((value,))[0]
        self._append_validated(entry)

    def _append_validated(self, entry: Mapping[str, TomlInput]) -> None:
        """Append an entry that has passed bulk-mutation preflight."""
        if self._layout_root is None:
            list.append(self, _make_unattached_entry(entry))
            return
        _layout_ops.add_aot_entry(self, entry)

    @override
    def extend(self, values: Iterable[Table | Mapping[str, TomlInput]]) -> None:
        # Snapshot so ``aot.extend(aot)`` duplicates once like list does.
        entries = _prepare_aot_entries(values)
        for entry in entries:
            self._append_validated(entry)

    @override
    def insert(
        self, index: SupportsIndex, value: Table | Mapping[str, TomlInput]
    ) -> None:
        entry = _prepare_aot_entries((value,))[0]
        if self._layout_root is None:
            list.insert(self, index, _make_unattached_entry(entry))
            return
        idx = _norm_insert_index(index, len(self))
        _layout_ops.add_aot_entry(self, entry, index=idx)

    @override
    def remove(self, value: Mapping[str, TomlInput]) -> None:
        _remove_value(self, value, "list.remove(x): x not in list")

    @override
    def reverse(self) -> None:
        if self._layout_root is None:
            list.reverse(self)
            return
        _layout_ops.renormalise_aot_order(self, list(reversed(self)))

    # Tables have no natural ordering, so unlike list.sort this API
    # deliberately requires a key.
    @override
    def sort(  # type: ignore[override]
        self,
        *,
        key: Callable[[Table], SupportsRichComparison],
        reverse: bool = False,
    ) -> None:
        if self._layout_root is None:
            list.sort(self, key=key, reverse=reverse)
            return
        _layout_ops.renormalise_aot_order(self, sorted(self, key=key, reverse=reverse))

    # Accept mappings as entries, matching append/extend rather than
    # exposing the narrower list[Table] storage type.
    @override
    def __iadd__(  # type: ignore[override]
        self, values: Iterable[Mapping[str, TomlInput]]
    ) -> Self:
        self.extend(values)
        return self

    @override
    def __imul__(self, count: SupportsIndex) -> Self:
        n = operator.index(count)
        if n <= 0:
            self.clear()
            return self
        if n == 1 or not self:
            return self
        if self._layout_root is None:
            from tomlrt._container import _copy_input  # noqa: PLC0415

            bodies = _prepare_aot_entries(self)
            copies: list[Table] = []
            for _ in range(n - 1):
                for body in bodies:
                    entry = _copy_input(body)
                    assert isinstance(entry, _container.Table)
                    copies.append(entry)
            list.extend(self, copies)
            return self
        originals = list(self)
        for _ in range(n - 1):
            for e in originals:
                _layout_ops.add_aot_entry(self, e)
        return self


def _prepare_aot_entries(
    values: Iterable[Mapping[str, TomlInput]],
) -> list[Mapping[str, TomlInput]]:
    """Snapshot entries, checking all mapping shapes before their contents."""
    from tomlrt._container import _validate_mapping_items  # noqa: PLC0415

    entries = list(values)
    for entry in entries:
        _require_mapping(entry, label="AoT entry")
    for entry in entries:
        _validate_mapping_items(entry, inline_only=False)
    return entries


def _make_unattached_entry(body: Mapping[str, TomlInput] | None) -> Table:
    """Build a fresh unattached `Table` view as an AoT-entry placeholder."""
    from tomlrt._container import Table, _populate_unattached  # noqa: PLC0415

    # Keep ordinary mappings free of cold-path imports and helper calls.
    if (
        isinstance(body, Table)
        and body._layout_root is not None  # noqa: SLF001
        and not body._inline  # noqa: SLF001
    ):
        from tomlrt._container import _clone_private_layout  # noqa: PLC0415

        entry = _clone_private_layout(body)
        assert isinstance(entry, Table)
        return entry
    t = Table()
    if body is not None:
        _populate_unattached(t, body)
    return t


__all__ = ["AoT", "Array"]
