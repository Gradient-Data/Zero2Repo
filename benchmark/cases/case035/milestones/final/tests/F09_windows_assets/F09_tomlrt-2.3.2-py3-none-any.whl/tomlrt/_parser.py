"""Hand-written recursive-descent parser.

Walks source via `_Scanner` and emits physical slots plus trailing
trivia. Drives `_Validator` for headers, key/value lines, and
inline-table keys.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from tomlrt._scanner import _Scanner
from tomlrt._slots import AoTEntry, KVSlot, StructuralHeaderSlot, stitch_run
from tomlrt._trivia import leading_has_blank_line, split_eol_section
from tomlrt._validator import _Validator
from tomlrt._values import (
    ArrayItem,
    ArrayValue,
    InlineTableEntry,
    InlineTableValue,
)

if TYPE_CHECKING:
    from tomlrt._slots import Slot
    from tomlrt._values import Value


class ParseResult:
    """The output of `_Parser.parse`.

    `slots` is in physical document order. `trailing` is EOF trivia;
    `newline` is the scanner-detected document-wide line ending.
    """

    __slots__ = ("newline", "section_blank_separated", "slots", "trailing")

    def __init__(self) -> None:
        self.slots: list[Slot] = []
        self.trailing = ""
        self.newline = "\n"
        self.section_blank_separated = True


class _Parser:
    __slots__ = ("_sc", "_validator", "_value_depth")

    _MAX_VALUE_DEPTH = 100

    def __init__(self, src: str) -> None:
        self._sc = _Scanner(src)
        self._validator = _Validator(self._sc.error)
        self._value_depth = 0

    def parse(self) -> ParseResult:
        result = ParseResult()
        sc = self._sc
        src = sc.src
        end = sc.end
        # The document's most recent inter-section gap is the one that
        # decides ``section_blank_separated``, so keep the gap itself
        # and classify it once at the end rather than at every header.
        latest_section_gap: str | None = None
        seen_header = False

        while sc.pos < end:
            leading = sc.scan_doc_trivia()
            pos = sc.pos
            if pos >= end:
                result.trailing += leading
                break

            ch = src[pos]
            slot: Slot
            if ch == "[":
                slot = self._parse_header(leading)
                if seen_header:
                    latest_section_gap = leading
                seen_header = True
            else:
                slot = self._parse_key_value(leading)
            result.slots.append(slot)

        stitch_run(None, result.slots, None)

        if latest_section_gap is not None:
            result.section_blank_separated = leading_has_blank_line(latest_section_gap)
        result.newline = sc.detected_newline()
        return result

    def _parse_header(self, leading: str) -> StructuralHeaderSlot:
        """Parse a ``[a.b]`` / ``[[a.b]]`` header.

        Precondition: cursor is at ``[``.
        """
        sc = self._sc
        src = sc.src
        header_at = sc.pos
        new_entry: AoTEntry | None
        if src.startswith("[[", sc.pos):
            sc.pos += 2
            new_entry = AoTEntry()
            closer, what = "]]", "array-of-tables"
        else:
            sc.pos += 1
            new_entry = None
            closer, what = "]", "table"

        inner_pre = sc.scan_inline_ws_text()
        key_parts, key_seps, inner_post, path = sc.scan_key()

        if not src.startswith(closer, sc.pos):
            msg = f"expected {closer!r} to close {what} header"
            raise sc.error(msg)
        sc.pos += len(closer)

        eol = sc.scan_eol()
        self._validator.enter_header(path, new_entry, at=header_at)
        owner = self._validator.current_owner_aot_entry

        slot = StructuralHeaderSlot(
            leading,
            owner,
            eol,
            key_parts,
            key_seps,
            path,
            inner_pre,
            inner_post,
            new_entry,
            synthetic=False,
        )
        if new_entry is not None:
            new_entry.bind_header(slot)
        return slot

    def _parse_key_value(self, leading: str) -> KVSlot:
        """Parse a ``key = value`` line.

        Precondition: cursor is at the start of the key.
        """
        sc = self._sc
        key_at = sc.pos
        key_parts, key_seps, pre_eq, key_path = sc.scan_key()
        src = sc.src
        pos = sc.pos
        if pos >= sc.end or src[pos] != "=":
            ch = src[pos] if pos < sc.end else ""
            msg = f"expected '=' after key, got {ch!r}"
            raise sc.error(msg)
        sc.pos = pos + 1
        post_eq = sc.scan_inline_ws_text()
        value = self._parse_value()
        eol = sc.scan_eol()

        self._validator.record_keyvalue(key_path, at=key_at)
        host_path = self._validator.current_section
        owner = self._validator.current_owner_aot_entry
        return KVSlot(
            leading,
            owner,
            eol,
            host_path,
            key_parts,
            key_seps,
            key_path,
            pre_eq,
            post_eq,
            value,
        )

    def _parse_value(self) -> Value:
        sc = self._sc
        pos = sc.pos
        ch = sc.src[pos] if pos < sc.end else ""
        if ch in {'"', "'"}:
            return sc.scan_string()
        if ch in ("[", "{"):
            if self._value_depth >= self._MAX_VALUE_DEPTH:
                msg = f"value nesting exceeds maximum depth ({self._MAX_VALUE_DEPTH})"
                raise sc.error(msg)
            self._value_depth += 1
            try:
                if ch == "[":
                    return self._parse_array()
                return self._parse_inline_table()
            finally:
                self._value_depth -= 1
        return sc.scan_value_atom()

    def _parse_array(self) -> ArrayValue:
        """Parse a ``[...]`` inline array.

        Precondition: cursor is at ``[``.
        """
        sc = self._sc
        src = sc.src
        sc.pos += 1
        node = ArrayValue()
        head = sc.scan_array_trivia()
        end = sc.end
        if sc.pos < end and src[sc.pos] == "]":
            # Empty array: head trivia is the canonical pre-`]` slot.
            node.opening = head
            sc.pos += 1
            return node
        node.opening = head
        items = node.items
        while True:
            value = self._parse_value()
            trailing = sc.scan_array_trivia()
            ch = src[sc.pos] if sc.pos < end else ""
            if ch == ",":
                sc.pos += 1
                post_comma, next_leading = split_eol_section(sc.scan_array_trivia())
            elif ch == "]":
                post_comma = next_leading = ""
            else:
                msg = f"expected ',' or ']' in array, got {ch!r}"
                raise sc.error(msg)
            item = ArrayItem(value, trailing, ch == ",", post_comma, next_leading)
            items.append(item)
            if sc.pos < end and src[sc.pos] == "]":
                if not item.has_comma:
                    item.before, item.following = split_eol_section(trailing)
                sc.pos += 1
                return node

    def _parse_inline_table(self) -> InlineTableValue:
        """Parse a ``{...}`` inline table.

        Precondition: cursor is at ``{``.
        """
        sc = self._sc
        src = sc.src
        end = sc.end
        sc.pos += 1
        node = InlineTableValue()
        head = sc.scan_array_trivia()
        if sc.pos < end and src[sc.pos] == "}":
            node.opening = head
            sc.pos += 1
            return node
        node.opening = head
        seen_prefixes: set[tuple[str, ...]] = set()
        entries = node.items
        while True:
            key_at = sc.pos
            key_parts, key_seps, pre_eq, key_path = sc.scan_key()
            self._validator.check_inline_key_conflict(
                key_path,
                node._key_index,  # noqa: SLF001
                seen_prefixes,
                at=key_at,
            )
            ch = src[sc.pos] if sc.pos < end else ""
            if ch != "=":
                msg = f"expected '=' in inline table, got {ch!r}"
                raise sc.error(msg)
            sc.pos += 1
            post_eq = sc.scan_inline_ws_text()
            value = self._parse_value()
            trailing = sc.scan_array_trivia()
            ch = src[sc.pos] if sc.pos < end else ""
            if ch == ",":
                sc.pos += 1
                post_comma, next_leading = split_eol_section(sc.scan_array_trivia())
            elif ch == "}":
                post_comma = next_leading = ""
            else:
                msg = f"expected ',' or '}}' in inline table, got {ch!r}"
                raise sc.error(msg)
            entry = InlineTableEntry(
                value,
                key_parts,
                key_seps,
                key_path,
                pre_eq,
                post_eq,
                trailing,
                ch == ",",
                post_comma,
                next_leading,
            )
            entries.append(entry)
            node.record_entry(entry)
            if sc.pos < end and src[sc.pos] == "}":
                if not entry.has_comma:
                    entry.before, entry.following = split_eol_section(trailing)
                sc.pos += 1
                return node


__all__ = ["ParseResult", "_Parser"]
