from __future__ import annotations


class VelnoraException(Exception):
    pass


class InvalidProjectFile(VelnoraException):
    pass
