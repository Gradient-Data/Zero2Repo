from __future__ import annotations

from typing import TYPE_CHECKING
from typing import Any

from cleo.helpers import argument
from cleo.helpers import option
from tomlkit.toml_document import TOMLDocument

from velnora.console.commands.command import Command


if TYPE_CHECKING:
    from poetry.core.semver.version import Version


class VersionCommand(Command):
    name = "version"
    description = (
        "Shows the version of the project or bumps it when a valid "
        "bump rule is provided."
    )

    arguments = [
        argument(
            "version",
            "The version number or the rule to update the version.",
            optional=True,
        )
    ]
    options = [
        option("short", "s", "Output the version number only"),
        option(
            "dry-run",
            None,
            "Do not update pyproject.toml file",
        ),
    ]

    help = """\
The version command shows the current version of the project or bumps the version of
the project and writes the new version back to <comment>pyproject.toml</> if a valid
bump rule is provided.

The new version should ideally be a valid semver string or a valid bump rule:
patch, minor, major, prepatch, preminor, premajor, prerelease.
"""

    RESERVED = {
        "major",
        "minor",
        "patch",
        "premajor",
        "preminor",
        "prepatch",
        "prerelease",
    }

    def handle(self) -> int:
        version = self.argument("version")

        if version:
            version = self.increment_version(
                self.velnora.package.pretty_version, version
            )

            if self.option("short"):
                self.line(version.to_string())
            else:
                self.line(
                    f"Bumping version from <b>{self.velnora.package.pretty_version}</>"
                    f" to <fg=green>{version}</>"
                )

            if not self.option("dry-run"):
                content: dict[str, Any] = self.velnora.file.read()
                velnora_content = content["tool"]["poetry"]
                velnora_content["version"] = version.text

                assert isinstance(content, TOMLDocument)
                self.velnora.file.write(content)
        else:
            if self.option("short"):
                self.line(self.velnora.package.pretty_version)
            else:
                self.line(
                    f"<comment>{self.velnora.package.name}</>"
                    f" <info>{self.velnora.package.pretty_version}</>"
                )

        return 0

    def increment_version(self, version: str, rule: str) -> Version:
        from poetry.core.semver.version import Version

        try:
            parsed = Version.parse(version)
        except ValueError:
            raise ValueError("The project's version doesn't seem to follow semver")

        if rule in {"major", "premajor"}:
            new = parsed.next_major()
            if rule == "premajor":
                new = new.first_prerelease()
        elif rule in {"minor", "preminor"}:
            new = parsed.next_minor()
            if rule == "preminor":
                new = new.first_prerelease()
        elif rule in {"patch", "prepatch"}:
            new = parsed.next_patch()
            if rule == "prepatch":
                new = new.first_prerelease()
        elif rule == "prerelease":
            if parsed.is_unstable():
                pre = parsed.pre
                assert pre is not None
                new = Version(parsed.epoch, parsed.release, pre.next())
            else:
                new = parsed.next_patch().first_prerelease()
        else:
            new = Version.parse(rule)

        return new
