from __future__ import annotations

from velnora.installation.operations.install import Install
from velnora.installation.operations.uninstall import Uninstall
from velnora.installation.operations.update import Update


__all__ = ["Install", "Uninstall", "Update"]
