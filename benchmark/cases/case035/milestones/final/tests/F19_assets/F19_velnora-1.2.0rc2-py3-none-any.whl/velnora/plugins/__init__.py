from __future__ import annotations

from velnora.plugins.application_plugin import ApplicationPlugin
from velnora.plugins.plugin import Plugin


__all__ = ["ApplicationPlugin", "Plugin"]
