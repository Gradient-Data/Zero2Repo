from __future__ import annotations

from cleo.exceptions import CleoSimpleException


class VelnoraSimpleConsoleException(CleoSimpleException):  # type: ignore[misc]
    pass
