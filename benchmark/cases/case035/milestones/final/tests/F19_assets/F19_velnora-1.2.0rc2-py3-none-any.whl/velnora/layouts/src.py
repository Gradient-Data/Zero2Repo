from __future__ import annotations

from pathlib import Path

from velnora.layouts.layout import Layout


class SrcLayout(Layout):
    @property
    def basedir(self) -> Path:
        return Path("src")
