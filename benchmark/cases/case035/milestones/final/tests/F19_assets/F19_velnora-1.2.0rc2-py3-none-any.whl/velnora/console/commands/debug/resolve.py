from __future__ import annotations

from cleo.helpers import argument
from cleo.helpers import option
from cleo.io.outputs.output import Verbosity

from velnora.console.commands.init import InitCommand
from velnora.console.commands.show import ShowCommand


class DebugResolveCommand(InitCommand):
    name = "debug resolve"
    description = "Debugs dependency resolution."

    arguments = [
        argument("package", "The packages to resolve.", optional=True, multiple=True)
    ]
    options = [
        option(
            "extras",
            "E",
            "Extras to activate for the dependency.",
            flag=False,
            multiple=True,
        ),
        option("python", None, "Python version(s) to use for resolution.", flag=False),
        option("tree", None, "Display the dependency tree."),
        option("install", None, "Show what would be installed for the current system."),
    ]

    loggers = ["velnora.repositories.pypi_repository", "velnora.inspection.info"]

    def handle(self) -> int:
        from cleo.io.null_io import NullIO
        from poetry.core.packages.project_package import ProjectPackage

        from velnora.factory import Factory
        from velnora.puzzle.solver import Solver
        from velnora.repositories.pool import Pool
        from velnora.repositories.repository import Repository
        from velnora.utils.env import EnvManager

        packages = self.argument("package")

        if not packages:
            package = self.velnora.package
        else:
            # Using current pool for determine_requirements()
            self._pool = self.velnora.pool

            package = ProjectPackage(
                self.velnora.package.name, self.velnora.package.version
            )

            # Silencing output
            verbosity = self.io.output.verbosity
            self.io.output.set_verbosity(Verbosity.QUIET)

            requirements = self._determine_requirements(packages)

            self.io.output.set_verbosity(verbosity)

            for constraint in requirements:
                name = constraint.pop("name")
                assert isinstance(name, str)
                extras = []
                for extra in self.option("extras"):
                    if " " in extra:
                        extras += [e.strip() for e in extra.split(" ")]
                    else:
                        extras.append(extra)

                constraint["extras"] = extras

                package.add_dependency(Factory.create_dependency(name, constraint))

        package.python_versions = self.option("python") or (
            self.velnora.package.python_versions
        )

        pool = self.velnora.pool

        solver = Solver(package, pool, [], [], self.io)

        ops = solver.solve().calculate_operations()

        self.line("")
        self.line("Resolution results:")
        self.line("")

        if self.option("tree"):
            show_command = self.application.find("show")
            assert isinstance(show_command, ShowCommand)
            show_command.init_styles(self.io)

            packages = [op.package for op in ops]

            requires = package.all_requires
            for pkg in packages:
                for require in requires:
                    if pkg.name == require.name:
                        show_command.display_package_tree(self.io, pkg, packages)
                        break

            return 0

        table = self.table(style="compact")
        table.style.set_vertical_border_chars("", " ")
        rows = []

        if self.option("install"):
            env = EnvManager(self.velnora).get()
            pool = Pool()
            locked_repository = Repository("velnora-locked")
            for op in ops:
                locked_repository.add_package(op.package)

            pool.add_repository(locked_repository)

            solver = Solver(package, pool, [], [], NullIO())
            with solver.use_environment(env):
                ops = solver.solve().calculate_operations()

        for op in ops:
            if self.option("install") and op.skipped:
                continue

            pkg = op.package
            row = [
                f"<c1>{pkg.complete_name}</c1>",
                f"<b>{pkg.version}</b>",
            ]

            if not pkg.marker.is_any():
                row[2] = str(pkg.marker)

            rows.append(row)

        table.set_rows(rows)
        table.render()

        return 0
