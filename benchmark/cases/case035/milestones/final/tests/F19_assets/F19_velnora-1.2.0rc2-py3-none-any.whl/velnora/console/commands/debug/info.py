from __future__ import annotations

import sys

from velnora.console.commands.command import Command


class DebugInfoCommand(Command):
    name = "debug info"
    description = "Shows debug information."

    def handle(self) -> int:
        velnora_python_version = ".".join(str(s) for s in sys.version_info[:3])

        self.line("")
        self.line("<b>Velnora</b>")
        self.line(
            "\n".join(
                [
                    f"<info>Version</info>: <comment>{self.velnora.VERSION}</>",
                    f"<info>Python</info>:  <comment>{velnora_python_version}</>",
                ]
            )
        )
        command = self.application.get("env info")

        exit_code: int = command.run(self.io)
        return exit_code
