from __future__ import annotations

from cleo.helpers import option

from velnora.console.commands.installer_command import InstallerCommand


class LockCommand(InstallerCommand):
    name = "lock"
    description = "Locks the project dependencies."

    options = [
        option(
            "no-update", None, "Do not update locked versions, only refresh lock file."
        ),
        option(
            "check",
            None,
            "Check that the <comment>velnora.lock</> file corresponds to the current"
            " version of <comment>pyproject.toml</>.",
        ),
    ]

    help = """
The <info>lock</info> command reads the <comment>pyproject.toml</> file from the
current directory, processes it, and locks the dependencies in the\
 <comment>velnora.lock</>
file.

<info>velnora lock</info>
"""

    loggers = ["velnora.repositories.pypi_repository"]

    def handle(self) -> int:
        self.installer.use_executor(
            self.velnora.config.get("experimental.new-installer", False)
        )

        if self.option("check"):
            if self.velnora.locker.is_locked() and self.velnora.locker.is_fresh():
                self.line("velnora.lock is consistent with pyproject.toml.")
                return 0
            self.line_error(
                "<error>"
                "Error: velnora.lock is not consistent with pyproject.toml. "
                "Run `velnora lock [--no-update]` to fix it."
                "</error>"
            )
            return 1

        self.installer.lock(update=not self.option("no-update"))

        return self.installer.run()
