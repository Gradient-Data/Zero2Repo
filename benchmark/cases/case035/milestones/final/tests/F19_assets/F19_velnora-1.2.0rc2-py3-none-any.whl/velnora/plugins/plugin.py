from __future__ import annotations

from abc import abstractmethod
from typing import TYPE_CHECKING

from velnora.plugins.base_plugin import BasePlugin


if TYPE_CHECKING:
    from cleo.io.io import IO

    from velnora.velnora import Velnora


class Plugin(BasePlugin):
    """
    Generic plugin not related to the console application.
    """

    group = "velnora.plugin"

    @abstractmethod
    def activate(self, velnora: Velnora, io: IO) -> None:
        raise NotImplementedError()
