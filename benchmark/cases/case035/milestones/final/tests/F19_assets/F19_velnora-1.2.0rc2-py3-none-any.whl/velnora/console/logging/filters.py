from __future__ import annotations

import logging


VELNORA_FILTER = logging.Filter(name="velnora")
