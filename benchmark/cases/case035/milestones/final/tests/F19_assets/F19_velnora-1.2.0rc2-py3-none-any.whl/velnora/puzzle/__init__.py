from __future__ import annotations

from velnora.puzzle.solver import Solver


__all__ = ["Solver"]
