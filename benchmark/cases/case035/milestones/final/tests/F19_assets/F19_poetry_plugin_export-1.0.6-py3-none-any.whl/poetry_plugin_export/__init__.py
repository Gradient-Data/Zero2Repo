from __future__ import annotations

from velnora.utils._compat import metadata


__version__ = metadata.version("poetry-plugin-export")  # type: ignore[no-untyped-call]
