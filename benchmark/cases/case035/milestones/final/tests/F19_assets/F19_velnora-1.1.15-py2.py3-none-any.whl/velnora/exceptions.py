class VelnoraException(Exception):

    pass


class InvalidProjectFile(VelnoraException):

    pass
