from cleo import Command as BaseCommand


class Command(BaseCommand):

    loggers = []

    @property
    def velnora(self):
        return self.application.velnora

    def reset_velnora(self):  # type: () -> None
        self.application.reset_velnora()
