from typing import TYPE_CHECKING

from .env_command import EnvCommand


if TYPE_CHECKING:
    from velnora.installation.installer import Installer
    from velnora.installation.installer import Optional


class InstallerCommand(EnvCommand):
    def __init__(self):
        self._installer = None  # type: Optional[Installer]

        super(InstallerCommand, self).__init__()

    def reset_velnora(self):
        super(InstallerCommand, self).reset_velnora()

        self._installer.set_package(self.velnora.package)
        self._installer.set_locker(self.velnora.locker)

    @property
    def installer(self):  # type: () -> Installer
        return self._installer

    def set_installer(self, installer):  # type: (Installer) -> None
        self._installer = installer
