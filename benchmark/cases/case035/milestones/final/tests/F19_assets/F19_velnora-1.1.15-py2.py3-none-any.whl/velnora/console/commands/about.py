from .command import Command


class AboutCommand(Command):

    name = "about"

    description = "Shows information about Velnora."

    def handle(self):
        self.line(
            """<info>Velnora - Package Management for Python</info>

<comment>Velnora is a dependency manager tracking local dependencies of your projects and libraries.
See <fg=blue>https://github.com/python-velnora/velnora</> for more information.</comment>"""
        )
