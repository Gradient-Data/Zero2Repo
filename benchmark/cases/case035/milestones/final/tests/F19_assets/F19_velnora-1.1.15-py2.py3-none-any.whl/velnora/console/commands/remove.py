from cleo import argument
from cleo import option

from .installer_command import InstallerCommand


class RemoveCommand(InstallerCommand):

    name = "remove"
    description = "Removes a package from the project dependencies."

    arguments = [argument("packages", "The packages to remove.", multiple=True)]
    options = [
        option("dev", "D", "Remove a package from the development dependencies."),
        option(
            "dry-run",
            None,
            "Output the operations but do not execute anything "
            "(implicitly enables --verbose).",
        ),
    ]

    help = """The <info>remove</info> command removes a package from the current
list of installed packages

<info>velnora remove</info>"""

    loggers = ["velnora.repositories.pypi_repository", "velnora.inspection.info"]

    def handle(self):
        packages = self.argument("packages")
        is_dev = self.option("dev")

        original_content = self.velnora.file.read()
        content = self.velnora.file.read()
        velnora_content = content["tool"]["poetry"]
        section = "dependencies"
        if is_dev:
            section = "dev-dependencies"

        # Deleting entries
        requirements = {}
        for name in packages:
            found = False
            for key in velnora_content[section]:
                if key.lower() == name.lower():
                    found = True
                    requirements[key] = velnora_content[section][key]
                    break

            if not found:
                raise ValueError("Package {} not found".format(name))

        for key in requirements:
            del velnora_content[section][key]

        # Write the new content back
        self.velnora.file.write(content)

        # Update packages
        self.reset_velnora()

        self._installer.use_executor(
            self.velnora.config.get("experimental.new-installer", False)
        )

        self._installer.dry_run(self.option("dry-run"))
        self._installer.verbose(self._io.is_verbose())
        self._installer.update(True)
        self._installer.whitelist(requirements)

        try:
            status = self._installer.run()
        except Exception:
            self.velnora.file.write(original_content)

            raise

        if status != 0 or self.option("dry-run"):
            # Revert changes
            if not self.option("dry-run"):
                self.line_error(
                    "\n"
                    "Removal failed, reverting pyproject.toml "
                    "to its original content."
                )

            self.velnora.file.write(original_content)

        return status
