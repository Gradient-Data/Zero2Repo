from __future__ import annotations

from typing import TYPE_CHECKING
from typing import Any
from typing import ClassVar

from cleo.commands.command import Command as BaseCommand
from cleo.exceptions import CleoValueError


if TYPE_CHECKING:
    from velnora.console.application import Application
    from velnora.velnora import Velnora


class Command(BaseCommand):
    loggers: ClassVar[list[str]] = []

    _velnora: Velnora | None = None

    @property
    def velnora(self) -> Velnora:
        if self._velnora is None:
            return self.get_application().velnora

        return self._velnora

    def set_velnora(self, velnora: Velnora) -> None:
        """Explicitly set the current Velnora.

        Useful for Plugins that extends the features of a Velnora CLI Command.
        """

        self._velnora = velnora

    def get_application(self) -> Application:
        from velnora.console.application import Application

        application = self.application
        assert isinstance(application, Application)
        return application

    def reset_velnora(self) -> None:
        self.get_application().reset_velnora()

    def option(self, name: str, default: Any = None) -> Any:
        try:
            return super().option(name)
        except CleoValueError:
            return default
