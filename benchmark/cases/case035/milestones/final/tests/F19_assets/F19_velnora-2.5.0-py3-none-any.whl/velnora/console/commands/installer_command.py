from __future__ import annotations

from typing import TYPE_CHECKING

from velnora.console.commands.env_command import EnvCommand
from velnora.console.commands.group_command import GroupCommand
from velnora.utils.password_manager import VelnoraKeyring


if TYPE_CHECKING:
    from cleo.io.io import IO

    from velnora.installation.installer import Installer


class InstallerCommand(GroupCommand, EnvCommand):
    def __init__(self) -> None:
        # Set in velnora.console.application.Application.configure_installer
        self._installer: Installer | None = None

        super().__init__()

    def reset_velnora(self) -> None:
        super().reset_velnora()

        self.installer.set_package(self.velnora.package)
        self.installer.set_locker(self.velnora.locker)

    @property
    def installer(self) -> Installer:
        assert self._installer is not None
        return self._installer

    def set_installer(self, installer: Installer) -> None:
        self._installer = installer

    def execute(self, io: IO) -> int:
        VelnoraKeyring.preflight_check(io, self.velnora.config)
        return super().execute(io)
