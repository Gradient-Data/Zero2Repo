from __future__ import annotations

import hashlib
import json
import logging
import shutil
import sys

from functools import cached_property
from importlib import metadata
from pathlib import Path
from site import addsitedir
from typing import TYPE_CHECKING

import tomlkit

from poetry.core.packages.project_package import ProjectPackage

from velnora.__version__ import __version__
from velnora.installation import Installer
from velnora.packages import Locker
from velnora.plugins.application_plugin import ApplicationPlugin
from velnora.plugins.plugin import Plugin
from velnora.repositories.installed_repository import InstalledRepository
from velnora.toml import TOMLFile
from velnora.utils._compat import tomllib
from velnora.utils.env import Env
from velnora.utils.env import EnvManager


if TYPE_CHECKING:
    from collections.abc import Sequence
    from typing import Any

    from cleo.io.io import IO
    from poetry.core.packages.dependency import Dependency
    from poetry.core.packages.package import Package

    from velnora.velnora import Velnora


logger = logging.getLogger(__name__)


class PluginManager:
    """
    This class registers and activates plugins.
    """

    def __init__(self, group: str) -> None:
        self._group = group
        self._plugins: list[Plugin] = []

    @staticmethod
    def add_project_plugin_path(directory: Path) -> None:
        from velnora.factory import Factory

        try:
            pyproject_toml = Factory.locate(directory)
        except RuntimeError:
            # no pyproject.toml -> no project plugins
            return

        plugin_path = pyproject_toml.parent / ProjectPluginCache.PATH
        if plugin_path.exists():
            # insert at the beginning to allow overriding dependencies
            EnvManager.get_system_env(naive=True).sys_path.insert(0, str(plugin_path))
            # process .pth files (among other things)
            addsitedir(str(plugin_path))

    @classmethod
    def ensure_project_plugins(cls, velnora: Velnora, io: IO) -> None:
        ProjectPluginCache(velnora, io).ensure_plugins()

    def load_plugins(self) -> None:
        plugin_entrypoints = self.get_plugin_entry_points()

        for ep in plugin_entrypoints:
            self._load_plugin_entry_point(ep)

    def get_plugin_entry_points(self) -> list[metadata.EntryPoint]:
        return list(metadata.entry_points(group=self._group))

    def activate(self, *args: Any, **kwargs: Any) -> None:
        for plugin in self._plugins:
            plugin.activate(*args, **kwargs)

    def _add_plugin(self, plugin: Plugin) -> None:
        if not isinstance(plugin, (Plugin, ApplicationPlugin)):
            raise TypeError(
                "The Velnora plugin must be an instance of Plugin or ApplicationPlugin"
            )

        self._plugins.append(plugin)

    def _load_plugin_entry_point(self, ep: metadata.EntryPoint) -> None:
        logger.debug("Loading the %s plugin", ep.name)

        plugin = ep.load()

        if not issubclass(plugin, (Plugin, ApplicationPlugin)):
            raise TypeError(
                "The Velnora plugin must be an instance of Plugin or ApplicationPlugin"
            )

        self._add_plugin(plugin())


class ProjectPluginCache:
    PATH = Path(".velnora") / "plugins"

    def __init__(self, velnora: Velnora, io: IO) -> None:
        self._velnora = velnora
        self._io = io
        self._path = velnora.pyproject_path.parent / self.PATH
        self._config_file = self._path / "config.toml"
        self._gitignore_file = self._path.parent / ".gitignore"

    @property
    def _plugin_section(self) -> dict[str, Any]:
        plugins = self._velnora.local_config.get("requires-plugins", {})
        assert isinstance(plugins, dict)
        return plugins

    @cached_property
    def _config(self) -> dict[str, Any]:
        return {
            "python": sys.version,
            "velnora": __version__,
            "plugins-hash": hashlib.sha256(
                json.dumps(self._plugin_section, sort_keys=True).encode()
            ).hexdigest(),
        }

    def ensure_plugins(self) -> None:
        from velnora.factory import Factory

        # parse project plugins
        plugins = []
        for name, constraints in self._plugin_section.items():
            _constraints = (
                constraints if isinstance(constraints, list) else [constraints]
            )
            for _constraint in _constraints:
                plugins.append(Factory.create_dependency(name, _constraint))

        if not plugins:
            if self._path.exists():
                self._io.write_line(
                    "<info>No project plugins defined."
                    " Removing the project's plugin cache</info>"
                )
                self._io.write_line("")
                shutil.rmtree(self._path)
            return

        if self._is_fresh():
            if self._io.is_debug():
                self._io.write_line("The project's plugin cache is up to date.")
                self._io.write_line("")
            return
        elif self._path.exists():
            self._io.write_line(
                "Removing the project's plugin cache because it is outdated"
            )
            # Just remove the cache for two reasons:
            # 1. Since the path of the cache has already been added to sys.path
            #    at this point, we had to distinguish between packages installed
            #    directly into Velnora's env and packages installed in the project cache.
            # 2. Updating packages in the cache does not work out of the box,
            #    probably, because we use pip to uninstall and pip does not know
            #    about the cache so that we end up with just overwriting installed
            #    packages and multiple dist-info folders per package.
            # In sum, we keep it simple by always starting from an empty cache
            # if something has changed.
            shutil.rmtree(self._path)

        # determine plugins relevant for Velnora's environment
        velnora_env = EnvManager.get_system_env(naive=True)
        relevant_plugins = {
            plugin.name: plugin
            for plugin in plugins
            if plugin.marker.validate(velnora_env.marker_env)
        }
        if not relevant_plugins:
            if self._io.is_debug():
                self._io.write_line(
                    "No relevant project plugins for Velnora's environment defined."
                )
                self._io.write_line("")
            self._write_config()
            return

        self._io.write_line(
            "<info>Ensuring that the Velnora plugins required"
            " by the project are available...</info>"
        )

        # check if required plugins are already available
        missing_plugin_count = len(relevant_plugins)
        satisfied_plugins = set()
        insufficient_plugins = []
        installed_packages = []
        installed_repo = InstalledRepository.load(velnora_env)
        for package in installed_repo.packages:
            if required_plugin := relevant_plugins.get(package.name):
                if package.satisfies(required_plugin):
                    satisfied_plugins.add(package.name)
                    installed_packages.append(package)
                else:
                    insufficient_plugins.append((package, required_plugin))
                    # Do not add the package to installed_packages so that
                    # the solver does not consider it.
                missing_plugin_count -= 1
                if missing_plugin_count == 0:
                    break
            else:
                installed_packages.append(package)

        if missing_plugin_count == 0 and not insufficient_plugins:
            # all required plugins are installed and satisfy the requirements
            self._write_config()
            self._io.write_line(
                "All required plugins have already been installed"
                " in Velnora's environment."
            )
            self._io.write_line("")
            return

        if insufficient_plugins and self._io.is_debug():
            plugins_str = "\n".join(
                f"  - {req}\n    installed: {p}" for p, req in insufficient_plugins
            )
            self._io.write_line(
                "The following Velnora plugins are required by the project"
                f" but are not satisfied by the installed versions:\n{plugins_str}"
            )

        # install missing plugins
        missing_plugins = [
            plugin
            for name, plugin in relevant_plugins.items()
            if name not in satisfied_plugins
        ]
        plugins_str = "\n".join(f"  - {p}" for p in missing_plugins)
        self._io.write_line(
            "The following Velnora plugins are required by the project"
            f" but are not installed in Velnora's environment:\n{plugins_str}\n"
            f"Installing Velnora plugins only for the current project..."
        )
        self._install(missing_plugins, velnora_env, installed_packages)
        self._io.write_line("")
        self._write_config()

    def _is_fresh(self) -> bool:
        if not self._config_file.exists():
            return False

        with self._config_file.open("rb") as f:
            stored_config = tomllib.load(f)

        return stored_config == self._config

    def _install(
        self,
        plugins: Sequence[Dependency],
        velnora_env: Env,
        installed_packages: Sequence[Package],
    ) -> None:
        project = ProjectPackage(name="velnora-project-instance", version="0")
        project.python_versions = ".".join(str(v) for v in velnora_env.version_info[:3])
        # consider all packages in Velnora's environment pinned
        for package in installed_packages:
            project.add_dependency(package.to_dependency())
        # add missing plugin dependencies
        for dependency in plugins:
            project.add_dependency(dependency)

        # force new package to be installed in the project cache instead of Velnora's env
        velnora_env.set_paths(purelib=self._path, platlib=self._path)

        self._ensure_cache_directory()

        installer = Installer(
            self._io,
            velnora_env,
            project,
            Locker(self._path / "velnora.lock", {}),
            self._velnora.pool,
            self._velnora.config,
            InstalledRepository(installed_packages),
        )
        installer.update(True)

        if installer.run() != 0:
            raise RuntimeError("Failed to install required Velnora plugins")

    def _write_config(self) -> None:
        self._ensure_cache_directory()

        document = tomlkit.document()

        for key, value in self._config.items():
            document[key] = value

        TOMLFile(self._config_file).write(data=document)

    def _ensure_cache_directory(self) -> None:
        if self._path.exists():
            return

        self._path.mkdir(parents=True, exist_ok=True)
        # only write .gitignore if path did not exist before
        self._gitignore_file.write_text("*", encoding="utf-8")
