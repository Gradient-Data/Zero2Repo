from __future__ import annotations

from typing import TYPE_CHECKING

from velnora.mixology.version_solver import VersionSolver


if TYPE_CHECKING:
    from poetry.core.packages.project_package import ProjectPackage

    from velnora.mixology.result import SolverResult
    from velnora.puzzle.provider import Provider


def resolve_version(root: ProjectPackage, provider: Provider) -> SolverResult:
    solver = VersionSolver(root, provider)

    return solver.solve()
