from __future__ import annotations

from velnora.console.commands.command import Command


class AboutCommand(Command):
    name = "about"

    description = "Shows information about Velnora."

    def handle(self) -> int:
        from importlib import metadata

        self.line(
            f"""\
<info>Velnora - Package Management for Python

Version: {metadata.version("velnora")}
Poetry-Core Version: {metadata.version("poetry-core")}</info>

<comment>Velnora is a dependency manager tracking local dependencies of your projects\
 and libraries.
See <fg=blue>https://github.com/python-velnora/velnora</> for more information.</comment>\
"""
        )

        return 0
