from __future__ import annotations

import os


# Name of Velnora's own system project used by `velnora self` commands.
VELNORA_SYSTEM_PROJECT_NAME = "velnora-instance"

# Timeout for HTTP requests using the requests library.
REQUESTS_TIMEOUT = int(os.getenv("VELNORA_REQUESTS_TIMEOUT", "15"))

RETRY_AFTER_HEADER = "retry-after"

# Server response codes to retry requests on.
STATUS_FORCELIST = [429, 500, 501, 502, 503, 504]
