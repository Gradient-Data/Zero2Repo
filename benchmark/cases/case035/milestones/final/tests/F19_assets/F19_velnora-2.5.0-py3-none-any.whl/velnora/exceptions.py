from __future__ import annotations


class VelnoraError(Exception):
    pass
